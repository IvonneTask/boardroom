
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `two_factor_secret` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `two_factor_recovery_codes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `two_factor_confirmed_at` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `two_factor_secret`, `two_factor_recovery_codes`, `two_factor_confirmed_at`, `remember_token`, `created_at`, `updated_at`, `username`) VALUES
(1, 'Ivonne Diaz', 'ivonne_perez.diaz@outlook.es', NULL, '$2y$10$YfO/zjw9RGYNsHQVl2FiNuD91AokqghDzdLzSygguk9LzIw2xUxyG', NULL, NULL, NULL, NULL, '2022-09-08 21:33:15', '2022-09-09 03:37:02', 'roninaran'),
(4, 'Andrea Calderon', 'andy@gmail.com', NULL, '$2y$10$.gX.Fwm2Yitf5DKQFJD1du38vTFnO8RbaYS.gmRfHJf8udaJodqt6', NULL, NULL, NULL, NULL, '2022-09-09 04:07:51', '2022-09-09 04:07:51', 'Andy'),
(5, 'Ivan Perez', 'orockero5@gmail.com', NULL, '$2y$10$KJQloaIfwsdEMFdL8xsSn.mpEbgDmq9BReXuLVTytcq/M9xBsAMV2', NULL, NULL, NULL, NULL, '2022-09-09 04:59:47', '2022-09-09 04:59:47', 'RedDark'),
(6, 'Cesar Diaz de Leon', 'cesar.diazleon@gmail.com', NULL, '$2y$10$4yby10vIcv8PQMTBjPqiGev6rVQCY78gJFARc9QJH2KhtvjlPiqGC', NULL, NULL, NULL, NULL, '2022-09-09 05:00:14', '2022-09-09 05:00:14', 'Cisar'),
(7, 'Jose Perez', 'jose.jp@gmail.com', NULL, '$2y$10$5v2kTWCs68uyDW4OWmC7aexFLXFOfvqqLyNU4avPVjgnNJB8ZGagK', NULL, NULL, NULL, NULL, '2022-09-09 05:00:34', '2022-09-09 05:00:34', 'JP'),
(8, 'Refugio Carrazco', 'jrefugio@gmail.com', NULL, '$2y$10$XjC8bvBDkeXnGau3JaH6d.pp0QWTF9N53nn7zWsMMNuOiYomdjGNa', NULL, NULL, NULL, NULL, '2022-09-09 05:01:06', '2022-09-09 05:01:06', 'JRefugio');
