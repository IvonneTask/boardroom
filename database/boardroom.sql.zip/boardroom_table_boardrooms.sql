
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `boardrooms`
--

CREATE TABLE `boardrooms` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `roomtype` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `reservdate` datetime NOT NULL,
  `start_time` time NOT NULL,
  `endtime` time NOT NULL,
  `state` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `updated_at` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` text COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `boardrooms`
--

INSERT INTO `boardrooms` (`id`, `username`, `roomtype`, `reservdate`, `start_time`, `endtime`, `state`, `updated_at`, `created_at`) VALUES
(6, 'roninaran', 'Boardroom', '2022-10-10 00:00:00', '09:00:00', '11:00:00', 'Occupied', '2022-09-08 23:18:34', '2022-09-08 23:18:34'),
(7, 'Andy', 'Livingroom', '2022-10-12 00:00:00', '10:00:00', '12:00:00', 'Occupied', '2022-09-08 23:21:39', '2022-09-08 23:21:39');
